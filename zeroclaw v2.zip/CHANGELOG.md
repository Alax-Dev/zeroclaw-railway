# Changelog

## v2.0.0 — 2026-04-30

### 🔴 Critical Fixes

- **Fixed NIM model IDs that caused 404 errors on every request**
  - GLM-5: `zai-org/glm-5` → `z-ai/glm5` (wrong org name)
  - Stable Diffusion 3.5: `stable-diffusion-3_5-large` → `stable-diffusion-3.5-large` (underscore → dot)
  - These two models were completely broken — they would never respond

- **Disabled reasoning mode on all models** (was causing 3-4 minute delays)
  - DeepSeek V4 Pro, Qwen 3.5, Qwen 3 Coder, GPT-5, Grok 3, Claude Sonnet all had `reasoning: true`
  - Without thinking budget control, models entered extended thinking chains
  - Set `thinkingDefault: "low"` for fast, bounded reasoning when needed

- **Removed duplicate `timeoutSeconds` in Telegram config** (was 30 AND 60)
  - JSON doesn't guarantee which key wins — caused unpredictable timeouts
  - Single value now: 180s

### 🟡 Performance Fixes

- **Agent timeout: 180s** — prevents requests from hanging forever
- **Telegram timeout: 180s** — matches agent timeout
- **Telegram retry: 3 attempts with jitter** — handles network hiccups
- **`pollingStallThresholdMs`: 60s** — prevents premature polling restarts
- **`bashForegroundMs`: 10s** — was 5s, too short for slow commands
- **Default model: Llama 3.3 70B** — much better at tool calling than Phi 4 Mini

### ✨ New Models

- **DeepSeek V4 Flash** (`/model deepseek-flash`) — fast 1M context, optimized for agents
- **GLM-5.1** (`/model glm`) — upgraded from GLM-5, better agentic capabilities
- **Qwen 3.5 397B** (`/model qwen-large`) — maximum capability Qwen model

### 📝 Other

- Updated README with all model changes and performance tuning docs
- Added CHANGELOG.md
- Updated `start.sh` startup banner with optimization info
- Fixed image model `input` types: `["text"]` → `["text", "image"]` for SD and FLUX
- Added `maxTokensField: "max_completion_tokens"` compat for Grok 3

## v1.0.0 — Initial Release

- 14 AI models from 3 providers (NIM, GitHub Models, Copilot)
- Telegram bot with admin-only access
- Full terminal access via `/bash`
- Image generation via NVIDIA NIM
- GitHub Copilot OAuth device flow
- Railway deployment with Dockerfile
